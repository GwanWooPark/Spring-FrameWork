create trigger INSERT_DEMO_PROD
    before insert
    on DEMO_PRODUCT_INFO
    for each row
DECLARE
  prod_id number;
BEGIN
  SELECT demo_prod_seq.nextval
    INTO prod_id
    FROM dual;
  :new.PRODUCT_ID := prod_id;
END;
/

